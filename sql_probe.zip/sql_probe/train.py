"""Train the tiny text-to-SQL model. Saves checkpoints + a log of held-out accuracy."""
import random, json, pickle, time, sys, numpy as np
import data
from model import TinyGPT, Adam

T_MAX = 64


def pad_batch(seqs):
    B = len(seqs); x = np.zeros((B, T_MAX), np.int64); tgt = np.zeros_like(x); w = np.zeros((B, T_MAX), np.float32)
    for i, s in enumerate(seqs):
        x[i, :len(s)] = s; tgt[i, :len(s) - 1] = s[1:]
        start = s.index(SQL_ID)                     # only learn to write the SQL, not the question
        w[i, start:len(s) - 1] = 1
    n = max(map(len, seqs)); return x[:, :n], tgt[:, :n], w[:, :n]


def generate(m, prompts, stoi, itos, max_new=40):
    """Greedy decode. Returns tokens + per-token probability (the 'output confidence')."""
    res = [None] * len(prompts); groups = {}
    for i, p in enumerate(prompts): groups.setdefault(len(p), []).append(i)
    eos = stoi["<eos>"]
    for n, idx in groups.items():
        seq = np.array([prompts[i] for i in idx]); probs = []; done = np.zeros(len(idx), bool)
        for _ in range(max_new):
            lg = m.forward(seq)["logits"][:, -1]; lg = lg - lg.max(-1, keepdims=True)
            pr = np.exp(lg); pr /= pr.sum(-1, keepdims=True)
            nxt = pr.argmax(-1); probs.append(pr.max(-1))
            seq = np.concatenate([seq, nxt[:, None]], 1); done |= nxt == eos
            if done.all() or seq.shape[1] >= T_MAX: break
        probs = np.array(probs).T
        for j, i in enumerate(idx):
            out = list(seq[j, n:]); k = out.index(eos) if eos in out else len(out)
            res[i] = ([itos[t] for t in out[:k]], probs[j, :k + (1 if k < len(out) else 0)])
    return res


if __name__ == "__main__":
    random.seed(0); np.random.seed(0)
    train = [data.make_example("train") for _ in range(12000)]
    itos, stoi = data.build_vocab(train); SQL_ID = stoi["<sql>"]
    val = [data.make_example(m) for m in ["common"] * 400 + ["rare"] * 150 + ["unseen"] * 150]
    m = TinyGPT(len(itos), d=64, L=4, H=4, T=T_MAX); opt = Adam(m.p)
    steps, B, lr0 = int(sys.argv[1]) if len(sys.argv) > 1 else 6000, 64, 3e-3
    enc = [data.encode(e, stoi) for e in train]; log = []; t0 = time.time()
    for st in range(1, steps + 1):
        x, tgt, w = pad_batch(random.sample(enc, B))
        loss, g = m.loss_and_grad(x, tgt, w)
        lr = lr0 * min(1, st / 300) * (0.1 + 0.9 * 0.5 * (1 + np.cos(np.pi * st / steps)))
        opt.step(m.p, g, lr)
        if st % 500 == 0 or st == steps:
            out = generate(m, [data.encode(e, stoi, False) for e in val], stoi, itos)
            acc = {}
            for e, (toks, _) in zip(val, out): acc.setdefault(e["meta"]["slice"], []).append(toks == e["sql"])
            acc = {k: round(float(np.mean(v)), 3) for k, v in acc.items()}
            log.append({"step": st, "loss": round(float(loss), 4), **acc})
            print(log[-1], f"{time.time() - t0:.0f}s", flush=True)
            pickle.dump({"p": m.p, "itos": itos, "cfg": dict(V=len(itos), d=64, L=4, H=4, T=T_MAX)},
                        open(f"ckpt/step{st}.pkl", "wb"))
    json.dump(log, open("results/train_log.json", "w"), indent=1)
