"""A small GPT-style transformer in pure numpy (forward + hand-written backward).

PyTorch could not be installed in this sandbox, so the model is written from scratch.
Pre-LayerNorm decoder, learned positions, multi-head causal attention, ReLU MLP.
`forward(..., keep=True)` also returns the residual stream after every layer,
which is what the probes read.
"""
import numpy as np

F = np.float32


class TinyGPT:
    def __init__(self, V, d=96, L=4, H=4, T=48, ff=4, seed=0):
        r = np.random.default_rng(seed)
        self.V, self.d, self.L, self.H, self.T = V, d, L, H, T
        s = 0.02
        p = {"E": r.normal(0, s, (V, d)), "P": r.normal(0, s, (T, d)),
             "gf": np.ones(d), "bf": np.zeros(d), "Wout": r.normal(0, s, (d, V))}
        for l in range(L):
            p.update({f"g1{l}": np.ones(d), f"b1{l}": np.zeros(d), f"g2{l}": np.ones(d), f"b2{l}": np.zeros(d),
                      f"Wq{l}": r.normal(0, s, (d, d)), f"Wk{l}": r.normal(0, s, (d, d)),
                      f"Wv{l}": r.normal(0, s, (d, d)), f"Wo{l}": r.normal(0, s / np.sqrt(2 * L), (d, d)),
                      f"W1{l}": r.normal(0, s, (d, ff * d)), f"c1{l}": np.zeros(ff * d),
                      f"W2{l}": r.normal(0, s / np.sqrt(2 * L), (ff * d, d)), f"c2{l}": np.zeros(d)})
        self.p = {k: v.astype(F) for k, v in p.items()}

    # ---------- primitives ----------
    @staticmethod
    def ln_f(x, g, b):
        mu = x.mean(-1, keepdims=True); var = x.var(-1, keepdims=True)
        rs = 1 / np.sqrt(var + 1e-5); xh = (x - mu) * rs
        return xh * g + b, (xh, rs, g)

    @staticmethod
    def ln_b(dy, c):
        xh, rs, g = c
        dg = (dy * xh).reshape(-1, xh.shape[-1]).sum(0); db = dy.reshape(-1, xh.shape[-1]).sum(0)
        dxh = dy * g
        dx = rs * (dxh - dxh.mean(-1, keepdims=True) - xh * (dxh * xh).mean(-1, keepdims=True))
        return dx, dg, db

    def heads(self, x):
        B, T, _ = x.shape; return x.reshape(B, T, self.H, -1).transpose(0, 2, 1, 3)

    def merge(self, x):
        B, H, T, dh = x.shape; return x.transpose(0, 2, 1, 3).reshape(B, T, H * dh)

    # ---------- forward ----------
    def forward(self, x, keep=False, grad=False):
        p = self.p; B, T = x.shape
        h = p["E"][x] + p["P"][:T]
        mask = np.triu(np.full((T, T), -1e9, F), 1)
        caches, resid, attns = [], [h], []
        for l in range(self.L):
            a, c1 = self.ln_f(h, p[f"g1{l}"], p[f"b1{l}"])
            q, k, v = (self.heads(a @ p[f"W{n}{l}"]) for n in "qkv")
            sc = 1 / np.sqrt(q.shape[-1])
            S = q @ k.transpose(0, 1, 3, 2) * sc + mask
            S = S - S.max(-1, keepdims=True); A = np.exp(S); A /= A.sum(-1, keepdims=True)
            o = self.merge(A @ v); h = h + o @ p[f"Wo{l}"]
            b, c2 = self.ln_f(h, p[f"g2{l}"], p[f"b2{l}"])
            z = b @ p[f"W1{l}"] + p[f"c1{l}"]; m = np.maximum(z, 0)
            h = h + m @ p[f"W2{l}"] + p[f"c2{l}"]
            if grad: caches.append((a, c1, q, k, v, A, o, b, c2, z, m, sc))
            if keep: resid.append(h); attns.append(A)
        y, cf = self.ln_f(h, p["gf"], p["bf"])
        logits = y @ p["Wout"]
        out = {"logits": logits}
        if keep: out["resid"] = resid; out["attn"] = attns
        if grad: out["cache"] = (x, caches, y, cf)
        return out

    def lens(self, h):
        """Logit lens: read an intermediate residual through the final LN + unembedding."""
        y, _ = self.ln_f(h, self.p["gf"], self.p["bf"]); return y @ self.p["Wout"]

    # ---------- loss + backward ----------
    def loss_and_grad(self, x, tgt, wmask):
        out = self.forward(x, grad=True); p = self.p
        lg = out["logits"]; lg = lg - lg.max(-1, keepdims=True)
        pr = np.exp(lg); pr /= pr.sum(-1, keepdims=True)
        n = wmask.sum()
        B, T = x.shape; bi, ti = np.meshgrid(np.arange(B), np.arange(T), indexing="ij")
        loss = -(np.log(pr[bi, ti, tgt] + 1e-9) * wmask).sum() / n
        dl = pr; dl[bi, ti, tgt] -= 1; dl *= (wmask / n)[..., None]
        x_, caches, y, cf = out["cache"]; g = {}
        g["Wout"] = y.reshape(-1, self.d).T @ dl.reshape(-1, self.V)
        dh, g["gf"], g["bf"] = self.ln_b(dl @ p["Wout"].T, cf)
        for l in reversed(range(self.L)):
            a, c1, q, k, v, A, o, b, c2, z, m, sc = caches[l]
            g[f"c2{l}"] = dh.reshape(-1, self.d).sum(0)
            g[f"W2{l}"] = m.reshape(-1, m.shape[-1]).T @ dh.reshape(-1, self.d)
            dz = (dh @ p[f"W2{l}"].T) * (z > 0)
            g[f"c1{l}"] = dz.reshape(-1, dz.shape[-1]).sum(0)
            g[f"W1{l}"] = b.reshape(-1, self.d).T @ dz.reshape(-1, dz.shape[-1])
            db_, g[f"g2{l}"], g[f"b2{l}"] = self.ln_b(dz @ p[f"W1{l}"].T, c2)
            dh = dh + db_
            g[f"Wo{l}"] = o.reshape(-1, self.d).T @ dh.reshape(-1, self.d)
            do = self.heads(dh @ p[f"Wo{l}"].T)
            dA = do @ v.transpose(0, 1, 3, 2); dv = A.transpose(0, 1, 3, 2) @ do
            dS = A * (dA - (dA * A).sum(-1, keepdims=True)) * sc
            dq = dS @ k; dk = dS.transpose(0, 1, 3, 2) @ q
            da = 0
            for nme, dd in (("q", dq), ("k", dk), ("v", dv)):
                dd = self.merge(dd)
                g[f"W{nme}{l}"] = a.reshape(-1, self.d).T @ dd.reshape(-1, self.d)
                da = da + dd @ p[f"W{nme}{l}"].T
            dx_, g[f"g1{l}"], g[f"b1{l}"] = self.ln_b(da, c1)
            dh = dh + dx_
        g["P"] = np.zeros_like(p["P"]); g["P"][:T] = dh.sum(0)
        g["E"] = np.zeros_like(p["E"]); np.add.at(g["E"], x_, dh)
        return loss, g


class Adam:
    def __init__(self, p, lr=3e-3, b1=0.9, b2=0.98, wd=0.01):
        self.lr, self.b1, self.b2, self.wd, self.t = lr, b1, b2, wd, 0
        self.m = {k: np.zeros_like(v) for k, v in p.items()}; self.v = {k: np.zeros_like(v) for k, v in p.items()}

    def step(self, p, g, lr):
        self.t += 1
        for k in p:
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g[k]
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * g[k] ** 2
            mh = self.m[k] / (1 - self.b1 ** self.t); vh = self.v[k] / (1 - self.b2 ** self.t)
            if p[k].ndim == 2: p[k] -= lr * self.wd * p[k]
            p[k] -= (lr * mh / (np.sqrt(vh) + 1e-8)).astype(F)
