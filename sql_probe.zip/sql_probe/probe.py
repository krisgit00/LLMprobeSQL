"""Probe the trained model: does it know, inside its layers, when it is about to guess?

Outputs results/results.json and figures/*.png
"""
import pickle, json, random, sys, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import data
from model import TinyGPT
from train import generate

ck = pickle.load(open(sys.argv[1], "rb")); itos = ck["itos"]; stoi = {w: i for i, w in enumerate(itos)}
m = TinyGPT(**ck["cfg"]); m.p = ck["p"]; L = m.L

random.seed(123)
test = [data.make_example(s) for s in ["common"] * 1400 + ["rare"] * 700 + ["unseen"] * 700]
prompts = [data.encode(e, stoi, False) for e in test]
outs = generate(m, prompts, stoi, itos)
con = data.make_db()
y = np.array([toks == e["sql"] for e, (toks, _) in zip(test, outs)], int)
y_exec = np.array([data.execute(con, toks) is not None and data.execute(con, toks) == data.execute(con, e["sql"])
                   for e, (toks, _) in zip(test, outs)], int)
slices = np.array([e["meta"]["slice"] for e in test])
has_unk = np.array([1 in p for p in prompts], int)
minprob = np.array([pr.min() for _, pr in outs]); meanlogp = np.array([np.log(pr + 1e-9).mean() for _, pr in outs])

# ---- residual stream at the <sql> token: the model has read the question, written nothing yet ----
acts = [np.zeros((len(test), m.d), np.float32) for _ in range(L + 1)]
groups = {}
for i, p in enumerate(prompts): groups.setdefault(len(p), []).append(i)
for n, idx in groups.items():
    r = m.forward(np.array([prompts[i] for i in idx]), keep=True)["resid"]
    for l in range(L + 1): acts[l][idx] = r[l][:, -1]

cv = StratifiedKFold(5, shuffle=True, random_state=0)
probe = lambda: make_pipeline(StandardScaler(), LogisticRegression(C=0.05, max_iter=2000))


def oof(X, lab):
    return cross_val_predict(probe(), X, lab, cv=cv, method="predict_proba")[:, 1]


R = {"n_test": len(test), "accuracy": {}, "exec_accuracy": {}}
for s in ["simple", "multi_cond", "rare", "unseen"]:
    R["accuracy"][s] = round(float(y[slices == s].mean()), 3); R["exec_accuracy"][s] = round(float(y_exec[slices == s].mean()), 3)
R["accuracy"]["all"] = round(float(y.mean()), 3); R["exec_accuracy"]["all"] = round(float(y_exec.mean()), 3)

# correctness probe per layer (all data, and with every <unk> example removed so it can't just spot unknown words)
nounk = has_unk == 0
R["probe_auc"] = []; R["probe_auc_no_unk"] = []; scores = {}
for l in range(L + 1):
    sc = oof(acts[l], y); scores[l] = sc
    R["probe_auc"].append(round(roc_auc_score(y, sc), 3))
    R["probe_auc_no_unk"].append(round(roc_auc_score(y[nounk], oof(acts[l][nounk], y[nounk])), 3))
R["baseline_auc"] = {"output_min_token_prob": round(roc_auc_score(y, minprob), 3),
                     "output_mean_logprob": round(roc_auc_score(y, meanlogp), 3),
                     "has_unknown_word": round(roc_auc_score(y, -has_unk), 3),
                     "question_length": round(roc_auc_score(y, -np.array([len(q) for q in prompts])), 3),
                     "question_length_no_unk": round(roc_auc_score(y[nounk], -np.array([len(q) for q in prompts])[nounk]), 3),
                     "output_min_token_prob_no_unk": round(roc_auc_score(y[nounk], minprob[nounk]), 3)}
best = int(np.argmax(R["probe_auc"])); R["best_layer"] = best

# what does each layer already "know" about the query it will write? (common wording only)
cm = slices != "unseen"
R["intent_acc"] = {}
for key in ["qtype", "table", "num_col"]:
    lab = np.array([e["meta"][key] for e in test]); accs = []
    for l in range(L + 1):
        pred = cross_val_predict(make_pipeline(StandardScaler(), LogisticRegression(C=0.05, max_iter=2000)),
                                 acts[l][cm], lab[cm], cv=StratifiedKFold(5, shuffle=True, random_state=0))
        accs.append(round(float((pred == lab[cm]).mean()), 3))
    R["intent_acc"][key] = accs

# ---- logit lens: at each layer, how sure is the model of the token it ends up writing? ----
lens_c, lens_w, heat = [], [], {}
for i, (e, (toks, _)) in enumerate(zip(test, outs)):
    if i % 3: continue
    gen = [stoi[t] for t in toks] + [stoi["<eos>"]]
    seq = np.array([prompts[i] + gen])[:, :64]
    r = m.forward(seq, keep=True)["resid"]; P0 = len(prompts[i]) - 1
    rows = []
    for l in range(L + 1):
        lg = m.lens(r[l][0, P0:P0 + len(gen)]); lg -= lg.max(-1, keepdims=True); pr = np.exp(lg); pr /= pr.sum(-1, keepdims=True)
        rows.append(pr[np.arange(len(gen[:pr.shape[0]])), gen[:pr.shape[0]]])
    rows = np.array(rows); (lens_c if y[i] else lens_w).append(rows.min(1))
    if y[i] and "ok" not in heat and e["meta"]["qtype"] == "list": heat["ok"] = (e, toks, rows)
    if not y[i] and "bad" not in heat and e["meta"]["qtype"] == "list" and slices[i] == "unseen": heat["bad"] = (e, toks, rows)
R["lens_correct"] = np.round(np.mean(lens_c, 0), 3).tolist(); R["lens_wrong"] = np.round(np.mean(lens_w, 0), 3).tolist()

# ---- where do errors happen? first wrong token ----
def kind(tok, e):
    if tok.isdigit(): return "number"
    if tok in data.SCHEMA: return "table"
    if tok.startswith("'"): return "text value"
    if tok in ("<", ">", "DESC", "ASC"): return "operator / order"
    if tok in data.AGG or tok == "COUNT": return "aggregate"
    if any(tok in T["num"] or tok in T["str"] for T in data.SCHEMA.values()): return "column"
    return "structure / length"
err = {}
for e, (toks, _), ok in zip(test, outs, y):
    if ok: continue
    gold = e["sql"]; j = next((k for k in range(min(len(toks), len(gold))) if toks[k] != gold[k]), min(len(toks), len(gold)))
    kd = kind(gold[j], e) if j < len(gold) else "structure / length"; err[kd] = err.get(kd, 0) + 1
R["first_error_kind"] = dict(sorted(err.items(), key=lambda kv: -kv[1]))

# ---- risk-coverage: if we only auto-run the queries the checker trusts most ----
def cov_curve(score):
    o = np.argsort(-score); return [round(float(y[o[:int(len(y) * c)]].mean()), 3) for c in (0.5, 0.6, 0.7, 0.8, 0.9, 1.0)]
combo = oof(np.c_[acts[best], np.log(minprob + 1e-9)], y)
R["coverage_levels"] = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
R["coverage_acc"] = {"probe_before_writing": cov_curve(scores[best]), "output_confidence": cov_curve(minprob),
                     "probe_plus_output": cov_curve(combo)}
R["combo_auc"] = round(roc_auc_score(y, combo), 3)
# guessing flag: share of wrong queries caught when flagging the riskiest 20%
o = np.argsort(scores[best]); flag = np.zeros(len(y), bool); flag[o[:int(0.2 * len(y))]] = True
R["flag20_catches_errors"] = round(float(flag[y == 0].mean()), 3); R["flag20_precision"] = round(float((y[flag] == 0).mean()), 3)
# which errors does each detector catch? flag the riskiest 20% of all queries by each score
thr_out = np.quantile(minprob, 0.2); thr_pr = np.quantile(scores[best], 0.2)
R["errors_caught_by_slice"] = {}
for s in ["simple", "multi_cond", "rare", "unseen"]:
    wm = (slices == s) & (y == 0)
    R["errors_caught_by_slice"][s] = {"n_errors": int(wm.sum()),
                                      "output_confidence": round(float((minprob[wm] <= thr_out).mean()), 3),
                                      "layer_probe": round(float((scores[best][wm] <= thr_pr).mean()), 3)}
R["flag20_output_catches_errors"] = round(float((minprob[y == 0] <= thr_out).mean()), 3)
R["confidently_wrong_share"] = round(float((minprob[y == 0] > 0.9).mean()), 3)
json.dump(R, open("results/results.json", "w"), indent=1)
print(json.dumps(R, indent=1))

# ================= figures =================
BLUE, ORANGE, AQUA, GRAY, INK, INK2 = "#2a78d6", "#eb6834", "#1baf7a", "#8a8984", "#0b0b0b", "#52514e"
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#c9c8c3",
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True,
                     "grid.color": "#ecebe7", "grid.linewidth": 0.8, "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb"})
LAYERS = ["embed"] + [f"L{l + 1}" for l in range(L)]


def save(f, name): f.tight_layout(); f.savefig(f"figures/{name}", dpi=160); plt.close(f)


# 1 accuracy by slice
f, ax = plt.subplots(figsize=(6.4, 3.4))
names = ["simple", "multi_cond", "rare", "unseen"]; labels = ["Common wording", "Two conditions", "Rare synonym", "Never-seen word"]
vals = [R["accuracy"][s] * 100 for s in names]
ax.barh(labels[::-1], vals[::-1], color=BLUE, height=0.55)
for i, v in enumerate(vals[::-1]): ax.text(v + 1, i, f"{v:.0f}%", va="center", color=INK)
ax.set_xlim(0, 110); ax.set_xlabel("Exact-match accuracy (%)"); ax.grid(axis="y", visible=False)
ax.set_title("Where the model gets SQL right", loc="left", color=INK, fontsize=12)
save(f, "1_accuracy_by_slice.png")

# 2 probe AUROC by layer
f, ax = plt.subplots(figsize=(6.8, 3.8))
ax.plot(LAYERS, R["probe_auc"], "-o", color=BLUE, lw=2, ms=8, label="Probe on layer (before any SQL is written)")
ax.plot(LAYERS, R["probe_auc_no_unk"], "-o", color=AQUA, lw=2, ms=8, label="Same, unknown-word questions removed")
ax.axhline(R["baseline_auc"]["output_min_token_prob"], color=ORANGE, lw=2, ls="--", label="Output confidence (after writing)")
ax.axhline(R["baseline_auc"]["question_length"], color=GRAY, lw=1.5, ls="-.", label="Question length alone")
ax.axhline(0.5, color=GRAY, lw=1, ls=":"); ax.text(0, 0.51, "coin flip", color=GRAY, fontsize=9)
ax.set_ylim(0.45, 1.0); ax.set_ylabel("AUROC: separates right vs wrong"); ax.set_xlabel("Layer")
ax.set_title("Can the layers tell it's about to be wrong?", loc="left", color=INK, fontsize=12)
ax.legend(frameon=False, fontsize=9, loc="lower right"); save(f, "2_guess_detector_by_layer.png")

# 3 intent decodability
f, ax = plt.subplots(figsize=(6.8, 3.8))
for key, c, lab in [("qtype", BLUE, "Query type (list/count/agg/top-k)"), ("table", ORANGE, "Which table"), ("num_col", AQUA, "Which number column")]:
    ax.plot(LAYERS, np.array(R["intent_acc"][key]) * 100, "-o", color=c, lw=2, ms=8, label=lab)
ax.set_ylim(0, 105); ax.set_ylabel("Probe accuracy (%)"); ax.set_xlabel("Layer")
ax.set_title("When does the plan appear? (read at the <sql> token)", loc="left", color=INK, fontsize=12)
ax.legend(frameon=False, fontsize=9, loc="lower right"); save(f, "3_plan_by_layer.png")

# 4 logit lens
f, ax = plt.subplots(figsize=(6.8, 3.8))
ax.plot(LAYERS, np.array(R["lens_correct"]) * 100, "-o", color=BLUE, lw=2, ms=8, label="Queries it got right")
ax.plot(LAYERS, np.array(R["lens_wrong"]) * 100, "-o", color=ORANGE, lw=2, ms=8, label="Queries it got wrong")
ax.set_ylim(0, 105); ax.set_ylabel("Prob. of its least-sure token (%)"); ax.set_xlabel("Layer")
ax.set_title("Weakest-token confidence, layer by layer (logit lens)", loc="left", color=INK, fontsize=12)
ax.legend(frameon=False, fontsize=9, loc="upper left"); save(f, "4_logit_lens.png")

# 5 risk-coverage
f, ax = plt.subplots(figsize=(6.8, 3.8)); cx = np.array(R["coverage_levels"]) * 100
for key, c, lab in [("probe_plus_output", BLUE, "Probe + output confidence"), ("output_confidence", ORANGE, "Output confidence only"),
                    ("probe_before_writing", AQUA, "Probe only (before writing)")]:
    ax.plot(cx, np.array(R["coverage_acc"][key]) * 100, "-o", color=c, lw=2, ms=8, label=lab)
ax.set_xlabel("% of queries auto-run (rest sent to a human)"); ax.set_ylabel("Accuracy of auto-run queries (%)")
ax.invert_xaxis(); ax.set_title("Trust the confident ones, review the rest", loc="left", color=INK, fontsize=12)
ax.legend(frameon=False, fontsize=9, loc="lower right"); save(f, "5_risk_coverage.png")

# 6 stacked per-layer heatmaps for one confident and one guessed query
f, axs = plt.subplots(2, 1, figsize=(8.6, 5.2))
for ax, k, ttl in [(axs[0], "ok", "Correct query"), (axs[1], "bad", "Wrong query, never-seen phrase")]:
    if k not in heat: ax.set_visible(False); continue
    e, toks, rows = heat[k]; cols = toks + ["<eos>"]
    ax.imshow(rows, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols, rotation=35, ha="right", fontsize=8)
    ax.set_yticks(range(L + 1)); ax.set_yticklabels(LAYERS, fontsize=8); ax.grid(False)
    ax.set_title(f"{ttl}:  \"{' '.join(e['q'])}\"", loc="left", fontsize=9, color=INK)
    for xi in range(rows.shape[1]): ax.text(xi, L, f"{rows[L, xi]:.2f}", ha="center", va="center", fontsize=7,
                                            color="white" if rows[L, xi] > 0.6 else INK)
f.suptitle("Per-layer confidence for each SQL token (darker = surer)", x=0.01, ha="left", fontsize=11, color=INK)
save(f, "6_token_layer_heatmaps.png")
json.dump({k: {"q": " ".join(v[0]["q"]), "gold": " ".join(v[0]["sql"]), "pred": " ".join(v[1])} for k, v in heat.items()},
          open("results/heatmap_examples.json", "w"), indent=1)
