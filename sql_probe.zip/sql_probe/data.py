"""Synthetic text-to-SQL task with controlled difficulty.

Every example is tagged with *why* it might be hard, so we can later ask
"does the model know when it is guessing?":
  common   - only frequent wording
  rare     - uses a synonym seen in <3% of training examples
  unseen   - uses a word never seen in training (becomes <unk>): the model MUST guess
  two_cond - two WHERE conditions (longer, more to copy)
"""
import random, sqlite3

SCHEMA = {
    "employees": {"syn": ["employees", "staff", "workers"], "rare": ["personnel"], "unseen": ["crew"],
                  "num": {"salary": (["salary", "pay"], ["earnings"], ["compensation"]),
                          "age": (["age"], ["years"], ["seniority"])},
                  "str": {"dept": (["department", "dept"], ["division"], ["unit"], ["sales", "hr", "it", "legal", "ops"]),
                          "city": (["city"], ["location"], ["town"], ["boston", "austin", "denver", "miami", "seattle"])},
                  "label": "name"},
    "orders": {"syn": ["orders", "purchases"], "rare": ["transactions"], "unseen": ["bookings"],
               "num": {"amount": (["amount", "total"], ["value"], ["spend"]),
                       "quantity": (["quantity"], ["units"], ["volume"])},
               "str": {"region": (["region"], ["area"], ["zone"], ["north", "south", "east", "west"]),
                       "status": (["status"], ["state"], ["stage"], ["open", "shipped", "returned", "pending"])},
               "label": "customer"},
    "products": {"syn": ["products", "items"], "rare": ["goods"], "unseen": ["merchandise"],
                 "num": {"price": (["price", "cost"], ["msrp"], ["tag"]),
                         "stock": (["stock"], ["inventory"], ["supply"])},
                 "str": {"category": (["category"], ["type"], ["genre"], ["toys", "tools", "books", "food"]),
                         "brand": (["brand"], ["maker"], ["vendor"], ["acme", "zenith", "nova", "apex"])},
                 "label": "name"},
}
OPS = {">": (["above", "over", "more than"], ["exceeding"], ["north of"]),
       "<": (["below", "under", "less than"], ["beneath"], ["shy of"])}
AGG = {"AVG": (["average"], ["mean"], ["typical"]), "MAX": (["highest", "largest"], ["peak"], ["maximal"]),
       "MIN": (["lowest", "smallest"], ["minimum"], ["least"]), "SUM": (["total"], ["combined"], ["aggregate"])}
RARE_P = 0.012


def num():
    """Numbers are written digit by digit (e.g. '4 7 1'), so the model has to copy them exactly."""
    return " ".join(str(random.randint(1, 9999)))


def pick(choices, mode, slot, flags):
    """choices=(common, rare, unseen). mode decides which bucket this slot may use."""
    common, rare, unseen = choices[0], choices[1], choices[2]
    if mode == "unseen" and slot == flags.get("unseen_slot"):
        return random.choice(unseen)
    if mode == "rare" and slot == flags.get("rare_slot"):
        return random.choice(rare)
    if mode == "train" and random.random() < RARE_P:
        flags["used_rare"] = True
        return random.choice(rare)
    return random.choice(common)


def make_example(mode="train"):
    """mode: train | common | rare | unseen. Returns dict(q, sql_tokens, meta)."""
    t = random.choice(list(SCHEMA)); T = SCHEMA[t]
    qtype = random.choices(["list", "count", "agg", "topk", "two_cond", "three_cond"], [3, 2, 2, 1.5, 1.5, 1.5])[0]
    slots = ["table", "num", "op"] + (["str"] if qtype in ("agg", "two_cond", "three_cond") else []) + (["agg"] if qtype == "agg" else [])
    if qtype == "topk": slots = ["table", "num"]
    flags = {"rare_slot": random.choice(slots), "unseen_slot": random.choice(slots)}
    tw = pick((T["syn"], T["rare"], T["unseen"]), mode, "table", flags)
    nc = random.choice(list(T["num"])); nw = pick(T["num"][nc], mode, "num", flags)
    op = random.choice(list(OPS)); ow = pick(OPS[op], mode, "op", flags)
    v = num(); v2 = num()
    nc2 = [c for c in T["num"] if c != nc][0]; nw2 = random.choice(T["num"][nc2][0])
    op2 = random.choice(list(OPS)); ow2 = random.choice(OPS[op2][0])
    sc = random.choice(list(T["str"])); sdef = T["str"][sc]
    sw = pick(sdef[:3], mode, "str", flags); sv = random.choice(sdef[3])
    lab = T["label"]
    if qtype == "list":
        q = f"list the {lab} of {tw} with {nw} {ow} {v}"
        sql = f"SELECT {lab} FROM {t} WHERE {nc} {op} {v}"
    elif qtype == "count":
        q = f"how many {tw} have {nw} {ow} {v}"
        sql = f"SELECT COUNT ( * ) FROM {t} WHERE {nc} {op} {v}"
    elif qtype == "agg":
        ag = random.choice(list(AGG)); aw = pick(AGG[ag], mode, "agg", flags)
        q = f"what is the {aw} {nw} of {tw} where {sw} is {sv}"
        sql = f"SELECT {ag} ( {nc} ) FROM {t} WHERE {sc} = '{sv}'"
    elif qtype == "topk":
        k = random.choice([1, 2, 3, 5]); d = random.choice(["top", "bottom"])
        q = f"show the {d} {k} {tw} by {nw}"
        sql = f"SELECT * FROM {t} ORDER BY {nc} {'DESC' if d == 'top' else 'ASC'} LIMIT {k}"
    elif qtype == "three_cond":
        q = f"list the {lab} of {tw} with {nw} {ow} {v} and {nw2} {ow2} {v2} and {sw} is {sv}"
        sql = f"SELECT {lab} FROM {t} WHERE {nc} {op} {v} AND {nc2} {op2} {v2} AND {sc} = '{sv}'"
    else:
        q = f"list the {lab} of {tw} with {nw} {ow} {v} and {sw} is {sv}"
        sql = f"SELECT {lab} FROM {t} WHERE {nc} {op} {v} AND {sc} = '{sv}'"
    meta = {"qtype": qtype, "table": t, "num_col": nc, "slice": mode if mode != "train" else "train"}
    if mode == "common": meta["slice"] = "multi_cond" if qtype in ("two_cond", "three_cond") else "simple"
    return {"q": q.split(), "sql": sql.split(), "meta": meta}


# ---------------- vocab ----------------
SPECIAL = ["<pad>", "<unk>", "<sql>", "<eos>"]


def build_vocab(examples):
    words = set()
    for e in examples: words.update(e["q"]); words.update(e["sql"])
    itos = SPECIAL + sorted(words)
    return itos, {w: i for i, w in enumerate(itos)}


def encode(e, stoi, with_sql=True):
    ids = [stoi.get(w, 1) for w in e["q"]] + [stoi["<sql>"]]
    if with_sql: ids += [stoi.get(w, 1) for w in e["sql"]] + [stoi["<eos>"]]
    return ids


# ---------------- execution check ----------------
def make_db(seed=0):
    r = random.Random(seed); con = sqlite3.connect(":memory:")
    for t, T in SCHEMA.items():
        cols = [T["label"]] + list(T["num"]) + list(T["str"])
        con.execute(f"CREATE TABLE {t} ({', '.join(cols)})")
        for i in range(80):
            row = [f"{T['label']}{i}"] + [r.randint(1, 9999) for _ in T["num"]] + [r.choice(T['str'][c][3]) for c in T["str"]]
            con.execute(f"INSERT INTO {t} VALUES ({','.join('?' * len(row))})", row)
    return con


def execute(con, tokens):
    try:
        out = []
        for t in tokens:                       # re-join digit tokens: '4 7 1' -> 471
            if t.isdigit() and out and out[-1].isdigit() and not (len(out) > 1 and out[-2] == "LIMIT"): out[-1] += t
            else: out.append(t)
        return sorted(map(repr, con.execute(" ".join(out)).fetchall()))
    except Exception:
        return None
