"""Same probe, on a real pretrained model. Run in a free Google Colab (T4 GPU) or Kaggle notebook.

NOT run yet: this sandbox can't reach HuggingFace. Expect to fix small things on first run.

    !pip -q install transformers accelerate scikit-learn
    # upload data.py next to this file, then:
    !python colab_real_model.py
"""
import random, json, numpy as np, torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score
import data

MODEL = "Qwen/Qwen2.5-0.5B-Instruct"   # try Qwen2.5-Coder-1.5B-Instruct next
N = 600                                 # questions per run (~10 min on a T4)

tok = AutoTokenizer.from_pretrained(MODEL)
model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float16, device_map="auto").eval()

SCHEMA_TXT = "\n".join(f"TABLE {t} ({T['label']}, {', '.join(list(T['num']) + list(T['str']))})" for t, T in data.SCHEMA.items())
SHOTS = [data.make_example("common") for _ in range(3)]


def prompt(e):
    shots = "".join(f"Q: {' '.join(s['q'])}\nSQL: {' '.join(s['sql'])}\n\n" for s in SHOTS)
    return f"Write SQLite for the question. Use only these tables.\n{SCHEMA_TXT}\n\n{shots}Q: {' '.join(e['q'])}\nSQL:"


def norm(s): return " ".join(s.replace("(", " ( ").replace(")", " ) ").replace('"', "'").split()).rstrip(";").strip()


random.seed(7)
test = [data.make_example(s) for s in ["common"] * (N // 2) + ["rare"] * (N // 4) + ["unseen"] * (N // 4)]
con = data.make_db(); acts, y, minp, sl = [], [], [], []
for e in test:
    ids = tok(prompt(e), return_tensors="pt").to(model.device)
    with torch.no_grad():
        hs = model(**ids, output_hidden_states=True).hidden_states          # (layers+1) x [1, T, d]
        acts.append(torch.stack([h[0, -1] for h in hs]).float().cpu().numpy())
        g = model.generate(**ids, max_new_tokens=40, do_sample=False, output_scores=True, return_dict_in_generate=True)
    new = g.sequences[0, ids["input_ids"].shape[1]:]
    text = tok.decode(new, skip_special_tokens=True).split("\n")[0]
    probs = [torch.softmax(s[0].float(), -1)[t].item() for s, t in zip(g.scores, new)]
    pred = data.execute(con, norm(text).split()); gold = data.execute(con, e["sql"])
    y.append(int(pred is not None and pred == gold)); minp.append(min(probs) if probs else 0); sl.append(e["meta"]["slice"])

acts, y, minp, sl = np.array(acts), np.array(y), np.array(minp), np.array(sl)
cv = StratifiedKFold(5, shuffle=True, random_state=0)
auc = [roc_auc_score(y, cross_val_predict(make_pipeline(StandardScaler(), LogisticRegression(C=0.01, max_iter=3000)),
                                          acts[:, l], y, cv=cv, method="predict_proba")[:, 1]) for l in range(acts.shape[1])]
R = {"model": MODEL, "exec_accuracy": {s: float(y[sl == s].mean()) for s in set(sl)},
     "probe_auc_by_layer": [round(a, 3) for a in auc], "output_confidence_auc": round(roc_auc_score(y, minp), 3)}
print(json.dumps(R, indent=1)); json.dump(R, open("real_model_results.json", "w"), indent=1)
